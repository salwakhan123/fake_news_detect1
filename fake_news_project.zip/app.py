from flask import Flask, request, render_template
import pickle

app = Flask(__name__)

model = pickle.load(open("model.pkl", "rb"))
vector = pickle.load(open("vector.pkl", "rb"))

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    news = request.form['news']
    data = vector.transform([news])
    result = model.predict(data)
    if result[0] == 0:
        output = "Fake News ❌"
    else:
        output = "Real News ✅"
    return render_template("index.html", prediction=output)

if __name__ == "__main__":
    app.run(debug=True)
